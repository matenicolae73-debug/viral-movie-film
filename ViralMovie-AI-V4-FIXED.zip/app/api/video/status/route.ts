import { NextResponse } from "next/server";

export async function POST(request: Request) {
  try {
    const b = await request.json();
    const id = String(b?.requestId || "").trim();
    if (!id) return NextResponse.json({error:"requestId is required."},{status:400});

    const key = process.env.FAL_KEY;
    if (!key) return NextResponse.json({ok:false,demo:true,message:"FAL_KEY is not configured."});

    const r = await fetch(
      `https://queue.fal.run/fal-ai/vidu/q3/text-to-video/turbo/requests/${encodeURIComponent(id)}`,
      {headers:{"Authorization":`Key ${key}`}}
    );
    const data = await r.json();
    return NextResponse.json({ok:r.ok,data},{status:r.ok?200:r.status});
  } catch {
    return NextResponse.json({ok:false,error:"Status request failed."},{status:500});
  }
}